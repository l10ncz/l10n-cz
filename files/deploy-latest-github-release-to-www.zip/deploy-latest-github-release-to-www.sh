#!/bin/bash
set -e

release_url=$(wget -O - https://api.github.com/repos/l10ncz/l10ncz/releases/latest | grep browser_download_url | cut -d '"' -f 4)
release_file_name=$(wget -O - https://api.github.com/repos/l10ncz/l10ncz/releases/latest | grep "name.*\.tar\.gz"  | cut -d '"' -f 4)
wget --output-document="www.$release_file_name" "$release_url"
rm -r ../www/*
tar -xvf "www.$release_file_name" -C ../www
echo "Released from: www.$release_file_name" > ../www/release.txt
